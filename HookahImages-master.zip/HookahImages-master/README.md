# HookahImages


To run the code, you should use Matlab 2017b or later version with full licence.


Install alexnet using Add-On Explorer


If you use the code, please cite our paper. Thanks!

Zhang, Youshan & Allem,, Jon-Patrick & Beth Unger, Jennifer & Cruz, Tess. (2018). Automated identification of hookahs (waterpipes) on Instagram: an application in feature extraction using Convolutional Neural Network and Support Vector Machine classification. Journal of Medical Internet Research. 10.2196/10513. 


To see the results:

Simple hit:
cnn_hooka.m

Or run test.m in the Testing folder.
